package dao;

import java.util.ArrayList;

public class MemberDAO {
	public ArrayList<String> getMemberList() {
		//p. 92
		return null;
		
	}
}

