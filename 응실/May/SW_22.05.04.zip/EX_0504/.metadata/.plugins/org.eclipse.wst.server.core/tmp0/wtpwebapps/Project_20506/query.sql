CREATE table test(id varchar2(5), pwd varchar(5))

INSERT INTO test values('aa','11');
INSERT INTO test values('bb','22');
INSERT INTO test values('cc','33');

select * FROM test;