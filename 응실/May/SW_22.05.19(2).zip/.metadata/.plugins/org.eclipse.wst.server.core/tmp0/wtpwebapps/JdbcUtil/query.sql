CREATE table test(
	id varchar2(5),
	pwd varchar(5)

);

INSERT INTO test VALUES ('aa','11');
INSERT INTO test VALUES ('bb','22');
INSERT INTO test VALUES ('cc','33');
INSERT INTO test VALUES ('dd','44');

SELECT * FROM test;

update test set pwd=999 where id='dd';
update test set id ='zz' where pwd=100;