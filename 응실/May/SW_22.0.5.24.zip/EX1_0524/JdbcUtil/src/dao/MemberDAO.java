package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import web.com.JDBCUtil;

public class MemberDAO {
	// ȸ�������ȸ ��� ����
	public ArrayList<String> getMemberList() {
		// p. 92
		ArrayList<String> list = new ArrayList<>();

		// DB ����
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select userid from member";

		conn = JDBCUtil.getConnection(); // JDBC ����̹� �޸� �ε�, DB ����
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				list.add(rs.getString("userid"));

			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, pstmt, rs);
		}

		return list;

	}

	// ȸ���߰� ��� ����
	public int insertMember(String userId, String userPwd) {
		int n = 0;

		// DB ����
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into member values(?, ?)";

		conn = JDBCUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPwd);
			n = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, pstmt);
			
		}
		return n;
	}
}
