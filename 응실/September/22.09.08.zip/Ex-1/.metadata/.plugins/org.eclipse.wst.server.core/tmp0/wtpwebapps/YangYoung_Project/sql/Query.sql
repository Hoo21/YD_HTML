CREATE TABLE BookShop (
	isbn VARCHAR2(15) PRIMARY KEY,
	title VARCHAR2(50) not null,
	author VARCHAR2(10) not null,
	company VARCHAR2(50),
	price NUMBER
);

insert into bookshop values('88-90-11', '자바무따기', '김자바', '디지털박스', 35000);
insert into bookshop values('90-10-12', '오라클3일완성', '이오라', '야메루출판사', 15000);
insert into bookshop values('87-90-33', 'JSP 달인되기', '송JP', '공갈닷컴', 20000);

SELECT * FROM bookshop;