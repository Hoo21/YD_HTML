package vo;

public class MemberVO {
	private String userId;
	private String userName;
	
	public MemberVO() {
		super();
	}

	//getter setter
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
