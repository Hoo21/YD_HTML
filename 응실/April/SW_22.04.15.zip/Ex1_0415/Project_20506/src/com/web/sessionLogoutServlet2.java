package com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/sessionLogout")
public class sessionLogoutServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public sessionLogoutServlet2() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("logOK");

		// session 속성(logOK)을 제거함 : removeAttribute() 또는 invalidate() 실행
		if (!id.isEmpty()) {
			session.removeAttribute("logOK"); // 또는 session.invalidate() 사용
			response.sendRedirect(request.getContextPath() + "/Session_2/sessionLoginForm.jsp");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
