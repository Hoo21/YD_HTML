create table table_1(
	id varchar2(5),
	pwd varchar(5)
);

insert into tbl_test1 values ('aa', '11');
insert into tbl_test1 values ('bb', '22');
insert into tbl_test1 values ('cc', '33');

select * from tbl_test1;

drop table tbl_test1;

select * from tab;
