-- 검색(*모든것) tab 명령어로 부터 모든 테이블 보여주기

SELECT * FROM tab;

-- 테이블 생성
-- CREATE TABLE tbl_text1();

CREATE TABLE tbl_test1(
	id varchar2(5),
	pwd varchar(5)
);

-- 테이블 검색
SELECT * FROM tbl_test1;

-- 레코드 추가
INSERT INTO tbl_test1 VALUES ('aa', '11');
INSERT INTO tbl_test1 VALUES ('bb', '22');
INSERT INTO tbl_test1 VALUES ('cc', '33');

-- 테이블 삭제
DROP TABLE tbl_test1;




