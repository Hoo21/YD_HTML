package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MemberDAO {
	public boolean getMemberPwd(String id, String pwd) {
		
		//DB 연동
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select userpwd from member where userid=?";
		boolean result = false;
		
		//107p 하단이어서
		
		return result;
	}
}
