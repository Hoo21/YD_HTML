package vo;

public class MemberVO {
}
