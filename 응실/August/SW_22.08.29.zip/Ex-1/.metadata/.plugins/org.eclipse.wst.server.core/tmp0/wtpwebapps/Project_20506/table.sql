-- 테이블 생성
CREATE table member(
	userid varchar2(10),
	userpwd varchar2(10)

);

CREATE table test(
	id varchar2(5),
	pwd varchar(5)

);

INSERT INTO member VALUES ('aa','11');
INSERT INTO member VALUES ('bb','22');
INSERT INTO member VALUES ('cc','33');
INSERT INTO member VALUES ('dd','44');

INSERT INTO member VALUES ('admin','5678');
INSERT INTO member VALUES ('candy','1234');


SELECT * FROM member;

update member set pwd=999 where id='dd';
update member set id ='zz' where pwd=100;

drop table member;
SELECT * FROM test;