package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import web.com.JDBCUtil;

public class MemberDAO {
	public ArrayList<String> getMemberList() {
		ArrayList<String> list = new ArrayList<>();
		
		//DB 연동
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select userId from member";
		
		conn = JDBCUtil.getConnection();  //JDBC 드라이버 메모리 로딩, DB 연결
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				list.add(rs.getString("userid"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, pstmt, rs);
		}
		
		return list;
		
	}
	
	public int insertMember(String userId, String userPwd) {
		int n = 0; 
		
		//DB 연동
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into member values(?, ?)";
		
		conn = JDBCUtil.getConnection();  //JDBC 드라이버 메모리 로딩, DB 연결
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  userId);
			pstmt.setString(2,  userPwd);
			n = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, pstmt);
		}
		
		return n;
		
	}
	
	public int updateMember(String userId, String userPwd) {
		int n = 0; 
		
		//DB 연동
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update member set userpwd=? where userid=?";
		
		conn = JDBCUtil.getConnection();  //JDBC 드라이버 메모리 로딩, DB 연결
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  userPwd);
			pstmt.setString(2,  userId);
			n = pstmt.executeUpdate();
			System.out.println(n);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, pstmt);
		}
		
		return n;
		
	}
}

