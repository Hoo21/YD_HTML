-- create table test();
-- art + x
create table test(
	userID varchar2(30),
	userPWD varchar2(20)
);

-- drop table member;

select * from test;

--insert into test(필드명) values(값);
insert into test(userID, userPWD) values('aa', '11');
insert into test(userID, userPWD) values('bb', '22');
insert into test(userID, userPWD) values('cc', '33');
insert into test(userID, userPWD) values('dd', '44');

-- 수정 (update)
update test set userPWD='154' where userID = 'dd';

-- 삭제 (delete)
delete from test where userID='dd'