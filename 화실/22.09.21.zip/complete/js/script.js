

// 문제1_메인메뉴  
// hover 이벤트
$(".menu").hover(function () {
        // over
        $(".sub-menu").stop().slideDown();
        
    }, function () {
        // out
        $(".sub-menu").stop().slideUp();
    }
);

// 문제2_ 공지사항 show/hide
//클릭이벤트: 팝업 띄우기.
//효과: show("slow") 동작
$(".notice-toggle").click(function (e) { 
    $("#popup1").show("slow");
    
});


// 문제3_팝업창 show/hide
// 클릭이벤트: 팝업 닫기
// 효과: hide("past")] 동작
$("#popup1").click(function (e) { 
    $("#popup1").hide("past");
    
});


// 문제4_ 공지사항 fadein/fadeout
// 클릭이벤트: 팝업 띄우기
// 효과: fadeTo("slow", 0.7)
$(".notice-fade").click(function (e) { 
    $("#popup2").fadeTo("slow", 0.7);
    
});


// 문제5_ 공지사항 닫기버튼 fadein/fadeout
// 클릭이벤트: 팝업 닫기
// 효과: fadeOut(1000)
$("#close").click(function (e) { 
    $("#popup2").fadeOut(1000);
    
});


