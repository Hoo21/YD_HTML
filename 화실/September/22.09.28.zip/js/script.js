// 이미지
var slide = $(".slide > img");

// 이미지카운트 변수
var sno = 0;

// 이미지전체갯수 - 1
var eno = slide.length - 1;

// 3초마다 모션_함수 실행
var timer = setInterval("autoslide()", 3000);



// 모션기능함수
function autoslide() {
    // 아래의 animate 함수 중 style과 speed만 사용했음 , 이후 function.
    //$(selector).animate("{style}", "speed", "easing", "callback");  
    $(slide[sno]).stop().animate(
        //{style}
        {
            // 1초동안 사라지는 효과
             left: "100%", opacity: "1", height: "300px"
            // left: "100%"
        },
        //speed
        1000,
        
        function () {
            $(this).css({
                // 화면에서 사라진 후에, 이미지값 초기화
                 left: "-100%", opacity: "1", height: "300px"
                // left: "-100%"
            });
        });

        // 나타날 이미지 카운트
        sno++;
        if (sno > eno) {
            // 이미지 카운트 초기화
            sno = 0;
        }

        // 두번째 이미지 _ 모션에서 나타나는 이미지 // opcacity를 지정해줌: 바뀌는 걸 막기 위해서.
        $(slide[sno]).stop().animate({
            left: "0", opacity: "1"
            // left: "0"
        }, 1000);
}
