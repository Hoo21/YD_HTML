

$(".menu").hover(
    function () {
        // over
        // $("sub-menu").slideDown("slow");
        // 이벤트가 여러번 호출될 때, 누적된 이벤트의 모션을 stop()으로 멈춰준다.
        $(".sub-menu").stop().slideDown("slow");
        
    }, function () {
        // out
        // $("sub-menu").slideDown("fast");
        // 이벤트가 여러번 호출될 때, 누적된 이벤트의 모션을 stop()으로 멈춰준다.

        $(".sub-menu").stop().slideUp("fast");

    }
);