//popUpBox
$('.notice li:nth-child(1)').click(function () {
    $('.popUpBox').stop().show();
})
$('.popUpBox button').click(function () {
    $('.popUpBox').stop().hide();
})