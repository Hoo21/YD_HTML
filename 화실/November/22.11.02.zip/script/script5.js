var slide = $(".slide > img");
var sno = 0;
var eno = slide.length - 1;

var timer = setInterval("autoslide()", 3000);

function autoslide(){
    // 화면 가운데 표시된 이미지 애니메이션
    $(slide[sno]).stop().animate({
        opacity: 0
    }, 1000);
    sno++;
    if (sno > eno) {
        sno = 0;
        
    }
    $(slide[sno]).stop().animate({
        opacity: 1
        // opacity: "1" 과 동일
    }, 1000);
}

// 기능사 문제에는 특별히 주어져있지않음
// 마우스 영역 벗어날 시 다시 자동 슬라이드
$(".slide").hover(
    function () {
        // over
        clearInterval(timer);
        
    }, function () {
        // out
        timer=setInterval("autoslide()", 3000);
            
        }
);
