var slide = $(".slide > img");
var sno = 0;
var eno = slide.length - 1;

var timer = setInterval("autoslide()", 3000);

function autoslide(){
    $(slide[sno]).stop().animate({
        left: "-100%"
    }, 1000, function(){
        $(this).css({left:"100%"});
    });
    sno++;
    if (sno > eno) {
        sno = 0;
        
    }
    $(slide[sno]).stop().animate({
        left: "0"
    }, 1000);
}

// 기능사 문제에는 특별히 주어져있지않음
// 마우스 영역 벗어날 시 다시 자동 슬라이드
$(".slide").hover(
    function () {
        // over
        clearInterval(timer);
        
    }, function () {
        // out
        timer=setInterval("autoslide()", 3000);
            
        }
);
