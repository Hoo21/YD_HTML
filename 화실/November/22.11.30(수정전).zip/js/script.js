// console 에서 확인.
// 정답이 될 랜덤값 설정
let randomNumber = Math.floor(Math.random() * 100) + 1;


// body page = document
const guesses = document.querySelector('.guesses');
const lastResult = document.querySelector('.lastResult');
const lowOrHi = document.querySelector('.lowOrHi');
const guessSubmit = document.querySelector('.guessSubmit');
const guessField = document.querySelector('.guessField');

let guessCount = 1;
let resetButton;

// 결과 체크
function checkGuess() {
    const userGuess = Number(guessField.value);
    // === :  
    if (guessCount === 1) {
        guesses.textContent = '입력한 숫자: ';
    }

    guesses.textContent += userGuess + ' ';
    
    if (userGuess === randomNumber) {
        // 축하메세지
        lastResult.textContent = 'Congratulations!축하축하! You got it right!';
        lastResult.style.backgroundColor = 'green';
        lowOrHi.textContent = '';

        // 정답 후에 게임종료
        setGameOver();
    } else if (guessCount === 10) {
        lastResult.textContent = '!!!GAME OVER!!!게임종료!!!';
        lowOrHi.textContent = '';

        // 오답으로 10회 경과 후에 게임종료
        setGameOver();
    } else {
        lastResult.textContent = '틀렸습니다!';
        lastResult.style.backgroundColor = 'red';
        if (userGuess < randomNumber) {
            lowOrHi.textContent = '값이 낮습니다!';            
        } else if(userGuess > randomNumber) {
            lowOrHi.textContent = '값이 높습니다!';
        }
    }

    guessCount++;
    guessField.value = '';
    guessField.focus();
}

// 버튼이벤트 : 결과보기
guessSubmit.addEventListener('click', checkGuess);

// 게임종료
function setGameOver() {
    guessField.disabled = true;
    guessSubmit.disabled = true;
    resetButton = document.createElement('button');
    resetButton.textContent = '게임 새로 시작하기';
    document.body.appendChild(resetButton);

    // 버튼이벤트 : 게임 새로 시작하기
    resetButton.addEventListener('click', resetGame);
}

// 게임 새로시작 설정
function resetGame() {
    guessCount = 1;
    const resetParas = document.querySelectorAll('.resultParas p');
    for (const resetPara of resetParas) {
        resetPara.textContent = '';
    }

    resetButton.parentNode.removeChild(resetButton);
    guessField.disabled = false;
    guessSubmit.disabled = false;
    guessField.value = '';
    guessField.focus();
    lastResult.style.backgroundColor = 'white';
    randomNumber = Math.floor(Math.random() * 100) + 1;
    
}