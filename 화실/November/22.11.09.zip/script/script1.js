//클릭한 공지사항 세부내용 팝업창으로 띄우기

function openPop(){
    $(".contentpop").show();
}
function closePop(){
    $(".contentpop").hide();
}