$(".main-menu").hover(
    function(){
        $(".sub-menu, .sub-back").stop().slideDown("slow");
    },function(){
        $(".sub-menu, .sub-back").stop().slideUp("fast");
    }
);