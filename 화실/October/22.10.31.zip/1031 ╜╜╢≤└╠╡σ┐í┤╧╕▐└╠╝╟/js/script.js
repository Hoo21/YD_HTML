/*
// 오른쪽에서 왼쪽으로 이동
setInterval(function () {
    $('.slideWrap').stop().animate({
        'margin-left': '-100%'
    }, function () {
        $('.slide:first').appendTo('.slideWrap')
        $('.slideWrap').css({ 'margin-left': '0%' })
    })
}, 3000)


//아래에서 위로 이동
setInterval(function () {
    $('.slideWrap').stop().animate({
        'margin-top': '-300px'
    }, function () {
        $('.slide:first').appendTo('.slideWrap')
        $('.slideWrap').css({ 'margin-top': '0px' })
    })
}, 3000)
*/

//fadeIn/fadeOut
$('.slide:gt(0)').hide()
setInterval(function () {
    $('.slide:first').fadeOut(1500).next().fadeIn(1500)
    $('.slide:first').appendTo('.slideWrap')
}, 3000)
