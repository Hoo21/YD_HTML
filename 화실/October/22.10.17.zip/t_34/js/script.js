//마우스 올렸을 때 보이기

$(".menu ul li").hover(
 function(){
  $(this).children("ul").stop().slideDown("slow");
 },
 function(){
  $(this).children("ul").stop().slideUp("fast");
 }
);

//클릭할 때 보이기
//$(".menu ul li").click(
// function(){
//  $(".menu ul li ul").hide();
//  $(this).children("ul").slideDown("slow");
// }
//);