$(".menu ul li").hover(
    function () {
        // $(this).children("ul").slideDown("slow");
        // 이벤트가 여러번 호출될 때, 누적된 이벤트의 모션을 stop()으로 멈춰준다.
        $(this).children("ul").stop().slideDown("slow");
        
    },
    function () {
        // $(this).children("ul").slideUp("fast");
        // 이벤트가 여러번 호출될 때, 누적된 이벤트의 모션을 stop()으로 멈춰준다.
        $(this).children("ul").stop().slideUp("fast");
    }
);