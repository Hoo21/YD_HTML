var div = $(".box");
var box = $(".box ul li");
var pop = $("#pop");
var popTitle = $("#pop .title");

div.hover(function () {
    //over
    //alert("BOX에는 " + box.length + " 개의 " + box.prop("tagName") + "가 있다.");
    div.css("background-color", "pink");
    }, function () {
    //out
    div.css("background-color", "");
    }
);

box.click(function (e) {
    // 1. 값 가져오기
    var liTitle = $(this).text();

    // 2. 값 적용하기
    popTitle.text(liTitle);

    // 3. 값 보여주기
    // pop.show(3000);
    pop.show("slow" , function() {
        alert(liTitle);
    });
});

pop.click(function (e) {
    // pop.hide(1000);
    pop.hide("past");
});




/*

box.click(function (e) {

    //----- 1. 토글기능 -----
    //  pop.toggle("slow");

    //----- 2. 선택값 추출 -> 토글기능 -> 추출한 값 출력 -----
    // alert("선택한 LI의 값은" + $(this).text() + "입니다.");
    // var liTitle = $(this).text();
     pop.toggle("slow", function () {
            alert(liTitle);
        });
    

    //----- 3. 선택값 추출 및 적용 -> 토글기능 -> 값의 변경 및 알림. -----
    // alert("선택한 LI의 값은" + $(this).text() + "입니다.");
    // var liTitle = $(this).text();
    // popTitle.text(liTitle);
     pop.toggle("slow", function () {
            alert("값이 변경되었습니다.");
        });
    


        pop.show("slow");
    });

*/