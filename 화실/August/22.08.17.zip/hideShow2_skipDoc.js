$(function () {
    //스크립트 작성
    //$("#hide").click();
    $("#hide").click(
        function () {
            $("p").hide();
        }
    );
    $("#show").click(
        function () {
            $("p").show();
        }
    );
}
);