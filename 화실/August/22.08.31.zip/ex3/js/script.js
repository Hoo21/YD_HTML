var divBox = $(".box");
var boxLi = $(".box ul li");
var pop = $("#pop");
var popTitle = $("#pop .title");
var popContent = $("#pop .content");

// 마우스 오버이벤트
divBox.hover(function () {
    // over
    // 1. this(나==me)를 사용하는 방법
    $(this).css("background-color", "pink");

    // 2. $() 셀렉터를 사용하는 방법
    // $(".box").css("background-color", "pink");

    // 3. var divBox 선언된 자바스크립트 변수를 사용하는 방법
    // divBox.css("background-color", "pink");

}, function () {
    // out
    // 1. this(나==me)를 사용하는 방법
    $(this).css("background-color", "");

    // 2. $() 셀렉터를 사용하는 방법
    // $(".box").css("background-color", "");

    // 3. var divBox 선언된 자바스크립트 변수를 사용하는 방법
    // divBox.css("background-color", "");

}
);


// 마우스 클릭이벤트
boxLi.click(function (e) {
    // 제목 적용
    var liTitle = $(this).text();
    popTitle.text("제목: " + liTitle);

    // 알림창
    alert(liTitle)
    
    // 내용 적용 - html 태그인식
    $("p").html("공지사항 <br>" + liTitle + "<br>>팝업내용입니다.");

    // 나타나는 효과
    // pop.fadeIn();

    // 3초 동안 나타나는 효과
    // pop.fadeIn(3000);

    // 천천히 나타나는 효과
    // pop.fadeIn("slow");

    // 천천히 나타나는 효과 (투명도 50%)
    pop.fadeTo("slow", 0.5);

});

/* 
pop.click(funtion (e) {
    // 사라지는 효과
    // $(this).fadeOut();

    // 1초 동안 사라지는 효과
    // $(this).fadeOut(1000);

    // 천천히 사라지는 효과
    // $(this).fadeOut("fast")
    
});
*/

$("#close").click(function (e) { 
    // pop.fadeOut();

    // pop.fadeOut(1000);

    pop.fadeOut("fast");
});